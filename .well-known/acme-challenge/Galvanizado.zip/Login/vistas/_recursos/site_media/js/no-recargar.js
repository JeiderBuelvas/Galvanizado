/*
function load_div(div, archivo){
	$("#" + div).load(archivo);}

*/

function load_div(div, archivo){
    $("#" + div).load(archivo);
}